<?php 

	$host = "localhost";
	$dbname = "alif_buku";
	$username = "root";
	$password = "0102";

 ?>