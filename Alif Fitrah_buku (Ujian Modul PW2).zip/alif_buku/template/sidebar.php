<div id="templatemo_content">
    
    	<div id="templatemo_left_column">
           	<h2>Partners</h2>
            <ul>
           	  <li><a href="#">Buku Terbaik</a> </li>
				<li><a href="#">Daftar Penulis</a></li>
            	<li><a href="#">Daftar Penerbit</a> </li>
				<li><a href="#">Daftar Buku</a></li>
                <li><a href="http://www.templatemo.com" target="_parent">Contact Alif Fitrah</a></li>
            </ul>
		  <h2>Testimonial</h2>
            	<img src="template/images/templatemo_thumb.gif" alt="image" />
				Duis vitae velit sed dui malesuada dignissim. Donec mollis aliquet ligula. Maecenas adipiscing elementum ipsum. <br /><a href="#">More</a>
		</div>