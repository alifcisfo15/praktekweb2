 <div id="templatemo_right_column">
	    	<h1>Welcome </h1>
            <p>This is a free CSS layout provided by <a href="http://www.templatemo.com" target="_blank">templatemo.com</a> website. Feel free to edit and apply this layout for your static or dynamic CMS websites. Photoshop credit goes to hawksmont ( http://hawksmont.deviantart.com ) for building  brush. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nunc quis sem nec tellus blandit tincidunt. </p>
    <p>Vestibulum dapibus tortor vel orci. Maecenas vulputate, arcu id fermentum eleifend, tortor enim tincidunt mauris, fringilla tincidunt purus urna vel risus. Fusce vulputate tellus ac felis.</p>
    
    
    			<h1>Validations</h1>
            	This layout template XHTML and CSS is  W3C compliant.<br />
                 
			   <a href="http://validator.w3.org/check?uri=referer"><img style="border:0;width:88px;height:31px" src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" width="88" height="31" vspace="8" border="0" /></a>
<a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;width:88px;height:31px"  src="http://jigsaw.w3.org/css-validator/images/vcss-blue" alt="Valid CSS!" vspace="8" border="0" /></a><br />                     
    
<div id="templatemo_section">
            	<h3>Our Gallery</h3>
                	<div class="subsection">
                     	<img src="images/templatemo_thumb.gif"  alt="image 1" /><br />
							Nam sit amet justo vel libero tincidunt dignissim. Fusce ac orci sit amet velit ultrices condimentum. <br /> <a href="#">more</a>                    
                    </div>
                    <div class="subsection">
                     	<img src="images/templatemo_thumb.gif"  alt="image 2" /><br />
							Ut id massa. Nullam nunc. Integer imperdiet odio ac eros. Ut id massa. Nullam nunc. <br /> <a href="#">more</a>                     
                     </div>
                     <div class="subsection">
                     	<img src="images/templatemo_thumb.gif"  alt="image 3" /><br />
							Fusce ac orci sit amet velit ultrices condimentum. Ut id massa. Nullam nunc.<br /> <a href="#">more</a>               
                     </div>                            
            </div>
		</div>
    </div>
    