<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Perpustakaan Sistem Informasi</title>
<meta name="keywords" content="construction, free CSS layout, XHTML website template" />
<meta name="description" content="buildings and constructions, download free CSS layout" />
<link href="template/templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<!--
This is a free CSS template provided by templatemo.com
-->
<div id="templatemo_container">

	<div id="templatemo_menu">
        <ul>
			<li><a href="#" class="current">Home</a></li>
   			<li><a href="#">Architects</a></li>
			<li><a href="#">Buildings</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>    	
    </div>
