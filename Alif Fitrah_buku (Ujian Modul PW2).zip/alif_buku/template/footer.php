
	    
       
	<div id="templatemo_footer">
    	<div class="left">
        		<img src="template/images/templatemo_smalllogo.gif" alt="logo" />
         		<h4>Office Address</h4>
                111/222 Lorem ipsum  dolor sit,<br />
                consectetuer adipiscing elit.<br />
                Nunc quis sem nec, 10020</div>
        <div class="right">
        		<a href="#">Home</a> | <a href="#">About Us</a> | <a href="#">Prices</a> | <a href="#">Member</a> | <a href="#">Contact Us</a><br />
        Copyright © 2048 <a href="#">Your Company Name</a> | <a href="http://www.iwebsitetemplate.com" target="_parent">Website Templates</a> by <a href="http://www.templatemo.com" target="_blank">templatemo.com</a>
        </div>
	</div>
</div>
  
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>