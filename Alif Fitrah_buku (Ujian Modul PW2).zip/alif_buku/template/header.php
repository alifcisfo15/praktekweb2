<div id="templatemo_header">
    	<img src="template/images/templatemo_logo.gif"  alt="logo" />
		<div id="templatemo_site_title">Information System<span>Library</span></div>
        <div id="templatemo_site_slogan">University of Tanjungpura</div>
	</div>