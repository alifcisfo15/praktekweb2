<?php 

include 'view/BukuUI.php';

$bk = new BukuUI();

$bk->tampilBuku();

 ?>

